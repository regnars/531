chrome.browserAction.onClicked.addListener(function(activeTab)
{
    chrome.tabs.create({ url: "531.html" });
});